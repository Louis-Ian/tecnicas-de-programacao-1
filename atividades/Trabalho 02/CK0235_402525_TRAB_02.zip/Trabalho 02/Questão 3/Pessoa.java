class Pessoa{
	String nome;
	int idade;

	void setNome(String pnome){
		nome = pnome;
	}

	String getNome(){
		return nome;
	}
}