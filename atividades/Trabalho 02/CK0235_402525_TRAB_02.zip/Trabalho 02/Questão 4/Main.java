class Main{
	public static void main(String args[]){
		
		Pessoa p1 = new Pessoa();
		p1.setNome("Ana");

		Pessoa p2 = new Pessoa();
		p2.setNome("Bruno");

		System.out.println ("Nome1:" + p1.getNome());
		System.out.println ("Nome2:" + p2.getNome());
	
	}
}